RESPONSIVE WEB DESIGN PROJECT

Files:
- index.html
- style.css
- images/

Responsive requirements:
- Mobile: one card per row.
- Tablet (min-width: 772px): cards are 45% wide and images have max-height: 30vh.
- Large screen (min-width: 998px): cards are 30% wide.

Open index.html in a browser to test the project.
